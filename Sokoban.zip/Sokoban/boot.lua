function Popipo()
    print("POPIPO")
end

function Game.Start()
    Engine.Scene:loadFromFile("Data/Maps/Menu.map.vili");
end