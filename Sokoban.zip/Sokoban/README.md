Author : PierrickLP
Date : 05/10/2018
Öbengine version : 0.9.9

A quick and dirty Sokoban made to test the engine.