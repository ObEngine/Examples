function Local.Init()
    print("Hello, World!");
end