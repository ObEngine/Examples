function Game.Start()
    -- Loads a Scene
    Engine.Scene:loadFromFile("Scenes/Empty.map.vili");
end